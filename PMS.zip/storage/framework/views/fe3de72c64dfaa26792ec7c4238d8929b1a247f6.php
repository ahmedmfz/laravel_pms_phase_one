<?php if(session()->has('success')): ?>

    <script>
        new Noty({
            type: 'success',
            layout: 'topRight',
            text: "<?php echo e(session()->get('success')); ?>",
            theme: 'sunset',
            timeout: 2500,
            killer: true
        }).show();
    </script>

<?php endif; ?> 

<?php if(session()->has('delete')): ?>

    <script>
        new Noty({
            type: 'error',
            layout: 'topRight',
            text: "<?php echo e(session()->get('delete')); ?>",
            theme: 'metroui',
            timeout: 2500,
            killer: true
        }).show();
    </script>

<?php endif; ?>

<?php if(session()->has('update')): ?>

    <script>
        new Noty({
            type: 'warning',
            layout: 'topRight',
            text: "<?php echo e(session()->get('update')); ?>",
            theme: 'relax',
            timeout: 2500,
            killer: true
        }).show();
    </script>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\PMS\resources\views/layouts/message.blade.php ENDPATH**/ ?>